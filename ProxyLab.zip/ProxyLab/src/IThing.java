
public interface IThing {

}