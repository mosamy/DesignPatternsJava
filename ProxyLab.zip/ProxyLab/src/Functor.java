@FunctionalInterface
public interface Functor {
	public void apply(String message);

}
