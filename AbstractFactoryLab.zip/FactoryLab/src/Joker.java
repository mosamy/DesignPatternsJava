
public class Joker {

}
