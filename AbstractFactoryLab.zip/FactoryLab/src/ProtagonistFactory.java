
public class ProtagonistFactory {
	

	
}
