
public class Batman extends SuperHero{

	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
}
