
public abstract class Villian implements Protagonist {
	
	public void doEvil()
	{
		System.out.println("I am doing evil!");
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "I'm a villian!";
	}

}
