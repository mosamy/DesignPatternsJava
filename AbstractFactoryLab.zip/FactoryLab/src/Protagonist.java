
public interface Protagonist {
	public String toString();

}
