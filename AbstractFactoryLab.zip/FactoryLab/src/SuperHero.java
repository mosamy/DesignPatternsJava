
public abstract class SuperHero  implements Protagonist{

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "I'm a superhero!";
	}

	public void savetheday()
	{
		System.out.println("I saved the day!");
	}
	
	 
}
