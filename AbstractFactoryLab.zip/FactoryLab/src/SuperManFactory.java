
public class SuperManFactory extends ProtagonistFactory {

}
