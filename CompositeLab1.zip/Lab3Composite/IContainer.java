
public interface IContainer extends IComponent {
	public void AddComponent(IComponent c);
	

}
