
public interface IComponent {
	public double computePrice();
	public double netPrice();
	public double discountPrice();

}
