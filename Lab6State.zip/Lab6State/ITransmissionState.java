
public interface ITransmissionState {

	public int gear();
	public int changegear(int speed);
	
}
