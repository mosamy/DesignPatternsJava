
public enum StyleType {Reverse, Above12, FunctorAbove12};


