
public enum CommandType {Push,Pop,Undo,Redo

};
