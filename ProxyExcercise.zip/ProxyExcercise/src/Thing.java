
public interface Thing {
	public void compute(String s);

}
