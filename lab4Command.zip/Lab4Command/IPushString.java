
public interface IPushString {

	public void setPushString(String value);
}
