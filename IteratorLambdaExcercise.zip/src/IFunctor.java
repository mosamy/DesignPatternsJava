
public interface IFunctor <T> {

	/*
	 * -
Functor<T>.compute(T element)
-
Functor<T>.getValue(

	 * 
	 * */
	public void compute(T element);
	
	T getValue();
}
